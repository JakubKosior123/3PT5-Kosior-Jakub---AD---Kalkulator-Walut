module com.example.etapii {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.etapii to javafx.fxml;
    exports com.example.etapii;
}