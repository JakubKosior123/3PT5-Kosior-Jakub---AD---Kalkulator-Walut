package com.example.etapiii_iv_v;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import org.json.*;

public class CurrencyManager {
    Map<String, Rate> rates = new HashMap<>();
    String json = null;

    public Map<String, Rate> getRates() {
        return rates;
    }

    public  ObservableList<String> getAvailableRatesCodes() {
        ObservableList<String> rates = FXCollections.observableArrayList();
        for (String key : this.rates.keySet()) {
            rates.add(key);
        }
        return rates;
    }

    public void Initalize() {
        try {
            URL url = new URL("https://api.nbp.pl/api/exchangerates/tables/A?format=json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            json = reader.readLine();
        } catch (Exception e) {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setContentText("Nie udało się pobrać kursów");
            a.show();
        }

        try {
            JSONArray array = new JSONArray(json);
            JSONObject main = array.getJSONObject(0);
            JSONArray rates = main.getJSONArray("rates");

            for (int i = 0; i < rates.length(); i++) {
                JSONObject rate = rates.getJSONObject(i);

                String currency = rate.getString("currency");
                String code = rate.getString("code");
                float mid = rate.getFloat("mid");

                Rate r = new Rate();
                r.currency = currency;
                r.code = code;
                r.mid = mid;

                this.rates.put(code, r);
            }

        } catch (Exception e) {
            Alert b = new Alert(Alert.AlertType.WARNING);
            b.setContentText("Błąd z JSON");
            b.show();
        }

        Rate pln = new Rate();
        pln.currency = "Polski złoty";
        pln.code = "PLN";
        pln.mid = 1.0f;
        this.rates.put(pln.code, pln);
    }
}
