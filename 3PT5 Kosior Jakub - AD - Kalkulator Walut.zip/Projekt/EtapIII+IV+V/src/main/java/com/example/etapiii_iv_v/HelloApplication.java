package com.example.etapiii_iv_v;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    CurrencyManager currencyManager = new CurrencyManager();

    TextField leftTextField = null;
    TextField rightTextField = null;

    ComboBox leftComboBox = null;
    ComboBox rightComboBox= null;

    Pane pane0 = null;
    Pane pane1 = null;
    Pane pane2 = null;
    Pane pane3 = null;
    Pane pane4 = null;
    Pane pane5 = null;
    Pane pane6 = null;
    Pane pane7 = null;
    Pane pane8 = null;
    Pane pane9 = null;

    Pane paneDot = null;
    Pane paneEqual = null;

    float leftValue = 0;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Jakub Kosior 3PT5");
        stage.setScene(scene);
        stage.show();

        currencyManager.Initalize();

        leftTextField = (TextField)scene.lookup("#leftTextField");
        rightTextField = (TextField)scene.lookup("#rightTextField");
        rightTextField.setEditable(false);

        leftComboBox = (ComboBox)scene.lookup("#leftCurrency");
        leftComboBox.setValue("PLN");
        rightComboBox = (ComboBox)scene.lookup("#rightCurrency");
        rightComboBox.setValue("PLN");

        leftComboBox.setItems(currencyManager.getAvailableRatesCodes());
        rightComboBox.setItems(currencyManager.getAvailableRatesCodes());

        leftComboBox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (leftComboBox.getValue() != "PLN" && rightComboBox.getValue() != "PLN")
                    rightComboBox.setValue("PLN");
            }
        });

        rightComboBox.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (rightComboBox.getValue() != "PLN" && leftComboBox.getValue() != "PLN")
                    leftComboBox.setValue("PLN");
            }
        });

        pane0 = (Pane)scene.lookup("#pane0");
        pane0.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "0");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane1 = (Pane)scene.lookup("#pane1");
        pane1.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "1");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane2 = (Pane)scene.lookup("#pane2");
        pane2.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "2");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane3 = (Pane)scene.lookup("#pane3");
        pane3.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "3");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane4 = (Pane)scene.lookup("#pane4");
        pane4.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "4");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane5 = (Pane)scene.lookup("#pane5");
        pane5.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "5");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane6 = (Pane)scene.lookup("#pane6");
        pane6.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "6");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane7 = (Pane)scene.lookup("#pane7");
        pane7.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "7");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane8 = (Pane)scene.lookup("#pane8");
        pane8.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "8");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        pane9 = (Pane)scene.lookup("#pane9");
        pane9.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "9");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        paneDot = (Pane)scene.lookup("#paneDot");
        paneDot.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + ".");
                leftTextField.positionCaret(leftTextField.getText().length());
            }
        });

        paneEqual = (Pane)scene.lookup("#paneEqual");
        paneEqual.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                leftTextField.setText(leftTextField.getText() + "");
                leftTextField.positionCaret(leftTextField.getText().length());
                String result = null;
                try {
                    leftValue = Float.parseFloat(leftTextField.getText());
                    if (leftComboBox.getValue() == "PLN") {
                        float val = leftValue / currencyManager.getRates().get(rightComboBox.getValue()).mid;
                        result = String.valueOf(val);
                    } else if (rightComboBox.getValue() == "PLN") {
                        float val = leftValue * currencyManager.getRates().get(leftComboBox.getValue()).mid;
                        result = String.valueOf(val);
                    }
                    rightTextField.setText(result);
                } catch (NumberFormatException e) {
                    rightTextField.setText("Złe dane!");
                }

            }
        });
    }

    public static void main(String[] args) {
        launch();
    }
}