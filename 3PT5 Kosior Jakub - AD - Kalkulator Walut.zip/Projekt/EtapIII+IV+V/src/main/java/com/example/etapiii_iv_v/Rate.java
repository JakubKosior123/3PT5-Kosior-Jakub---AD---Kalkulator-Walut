package com.example.etapiii_iv_v;

public class Rate {
    public String currency;
    public String code;
    public float mid;
}
